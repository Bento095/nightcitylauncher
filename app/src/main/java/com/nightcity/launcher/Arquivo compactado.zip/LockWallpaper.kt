package com.nightcity.launcher

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.Build
import androidx.compose.ui.graphics.toArgb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.min
import kotlin.math.max

/** Creates and applies the NightCity theme wallpaper to the LOCK screen only. */
suspend fun applyNcLockWallpaper(context: Context, palette: NcPalette) = withContext(Dispatchers.IO) {
    runCatching {
        val wm = WallpaperManager.getInstance(context.applicationContext)
        val w = maxOf(720, wm.desiredMinimumWidth.takeIf { it > 0 } ?: 1080)
        val h = maxOf(1280, wm.desiredMinimumHeight.takeIf { it > 0 } ?: 2400)
        val scale = min(1f, 1440f / w)
        val width = (w * scale).toInt().coerceAtLeast(720)
        val height = (h * scale).toInt().coerceAtLeast(1280)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val base = palette.bg.toArgb()
        val main = palette.y.toArgb()
        val cold = palette.c.toArgb()
        val alert = palette.r.toArgb()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Split composition: dark field on the left, theme accent field on the right.
        canvas.drawColor(base)
        paint.color = main
        canvas.drawRect(width * 0.53f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.color = palette.bg2.toArgb()
        canvas.drawRect(width * 0.48f, 0f, width * 0.53f, height.toFloat(), paint)

        // Irregular angular divider inspired by the supplied lock-screen artwork.
        val x = width * 0.53f
        val path = Path().apply {
            moveTo(x, 0f)
            lineTo(x, height * 0.10f)
            lineTo(x - width * 0.055f, height * 0.13f)
            lineTo(x - width * 0.055f, height * 0.28f)
            lineTo(x, height * 0.31f)
            lineTo(x, height * 0.48f)
            lineTo(x - width * 0.06f, height * 0.51f)
            lineTo(x - width * 0.06f, height * 0.68f)
            lineTo(x, height * 0.71f)
            lineTo(x, height * 0.88f)
            lineTo(x - width * 0.04f, height * 0.91f)
            lineTo(x - width * 0.04f, height.toFloat())
        }
        paint.color = cold
        paint.strokeWidth = max(3f, width * 0.006f)
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.SQUARE
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.FILL

        // Subtle tech-line texture on the dark half.
        paint.color = cold
        paint.alpha = 55
        val lineStep = maxOf(24, height / 48)
        for (i in 1..30) {
            val yy = (height * i / 32f).coerceAtMost(height.toFloat())
            canvas.drawRect(width * 0.04f, yy, width * (0.18f + (i % 4) * 0.07f), yy + maxOf(1f, width * 0.002f), paint)
        }
        paint.alpha = 255

        // Accent ticks and hazard slashes around the central seam.
        paint.color = alert
        paint.alpha = 150
        val tickW = maxOf(3f, width * 0.008f)
        for (i in 0..24) {
            val yy = height * (0.06f + i * 0.035f)
            canvas.drawRect(x + width * 0.025f, yy, x + width * 0.025f + tickW, yy + height * 0.008f, paint)
        }
        paint.color = cold
        paint.alpha = 210
        for (i in 0..10) {
            val yy = height * (0.12f + i * 0.07f)
            val slash = Path().apply {
                moveTo(x - width * 0.03f, yy)
                lineTo(x - width * 0.015f, yy + height * 0.012f)
                lineTo(x - width * 0.02f, yy + height * 0.012f)
                lineTo(x - width * 0.035f, yy)
                close()
            }
            canvas.drawPath(slash, paint)
        }
        paint.alpha = 255

        // Sparse dot-grid in both halves, intentionally low contrast.
        paint.color = cold
        paint.alpha = 45
        val dot = maxOf(2f, width * 0.0025f)
        val spacing = maxOf(22, width / 36)
        for (yy in (height / 10)..(height * 9 / 10) step (spacing * 2)) {
            for (xx in width / 20 until width * 9 / 20 step spacing) {
                canvas.drawCircle(xx.toFloat(), yy.toFloat(), dot, paint)
            }
        }
        paint.alpha = 255

        // Fine scratches/lines on the accent side for texture without compromising contrast.
        paint.color = base
        paint.alpha = 35
        for (i in 0..15) {
            val yy = height * (0.04f + i * 0.061f)
            canvas.drawRect(x + width * 0.12f, yy, width * (0.94f - (i % 3) * 0.04f), yy + 2f, paint)
        }
        paint.alpha = 255

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            wm.setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK)
        }
        bitmap.recycle()
    }
}
